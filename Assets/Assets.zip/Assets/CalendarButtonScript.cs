using UnityEngine;
using UnityEngine.SceneManagement;

public class CalendarButtonScript : MonoBehaviour
{
   
    public void GoToCalendarScene()
    {
        SceneManager.LoadScene("Calendar");  
    }
}
