using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeButtonScript : MonoBehaviour
{
   
    public void GoToHomeScene()
    {
        SceneManager.LoadScene("Home");  
    }
}
